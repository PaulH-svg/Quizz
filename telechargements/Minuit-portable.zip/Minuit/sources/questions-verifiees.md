# Les 30 questions de Minuit — dossier de vérification

Vérification documentaire effectuée le **30 octobre 2026**. Les 30 énoncés, réponses, indices et explications ont été confrontés aux passages cités. Les indices orthographiques sont construits à partir des noms établis par les références.

**32 pages distinctes consultées** : 19 versions figées de Wikipédia, 11 notices de Britannica et 2 articles de l’INA. Les liens Wikipédia utilisent un identifiant de révision pour conserver le texte contrôlé. Les autres pages peuvent être mises à jour par leurs éditeurs.

Le contrôle automatisé vérifie la disponibilité des pages et la présence littérale des citations ; il ne remplace pas la lecture et le contrôle factuel. Le [rapport technique](source-verification.json) conserve les résultats, les dates et les empreintes. Le script `python scripts/verify-sources.py` permet de renouveler ce contrôle sans désactiver TLS.

Les questions ne désignent aucun auteur dans les affaires non résolues. Le cas du collier distingue explicitement réputation et culpabilité. La question sur Weidmann distingue dernière exécution **publique** et dernière exécution en France. Le thème reste sans détails graphiques.

Cette banque utilise des **indices textuels**. Elle ne contient pas encore d’images de films. Le mode à trois images est disponible pour des visuels dont la provenance et les droits auront été vérifiés.

## 01. Un masque dans la nuit

**Thème :** Pop culture

Dans quel film de 1978 Michael Myers revient-il à Haddonfield ?

**Réponse : Halloween : La Nuit des masques**

- Indice à 2 points : Le film est réalisé par John Carpenter.
- Indice à 1 point : Laurie Strode y est interprétée par Jamie Lee Curtis.

Accepter « Halloween » ou « La Nuit des masques ». Il s’agit du film de John Carpenter sorti en 1978.

**Référence :** [Wikipédia, contributeurs — Halloween : La Nuit des masques — version 240048236](https://fr.wikipedia.org/w/index.php?oldid=240048236)

Passage : Introduction : « est un film d'horreur américain réalisé par John Carpenter , sorti en 1978 . » […] « Michael Myers ( Nick Castle et Tony Moran ) » […] « retourne dans sa ville, Haddonfield. » […] « croisant notamment sur sa route la baby-sitter Laurie Strode ( Jamie Lee Curtis ). »

Consultée le 2026-10-30.

## 02. À la source du vampire

**Thème :** Pop culture

Quel écrivain a publié le roman Dracula en 1897 ?

**Réponse : Bram Stoker**

- Indice à 2 points : C’est un écrivain irlandais.
- Indice à 1 point : Son prénom est Bram.

Bram Stoker publie Dracula en 1897. Le roman adopte une forme épistolaire.

**Référence :** [Wikipédia, contributeurs — Dracula — version 240645928](https://fr.wikipedia.org/w/index.php?oldid=240645928)

Passage : Introduction : « Dracula est un roman épistolaire de l'écrivain irlandais Bram Stoker publié en 1897. »

Consultée le 2026-10-30.

## 03. Un hôtel pour l’hiver

**Thème :** Pop culture

Comment s’appelle l’hôtel dont Jack Torrance devient le gardien dans Shining ?

**Réponse : L’Overlook**

- Indice à 2 points : Cet hôtel isolé se trouve dans le Colorado.
- Indice à 1 point : Son nom commence par « Over… ».

Accepter « Overlook » ou « Hôtel Overlook ». Jack Torrance est engagé pour y assurer le gardiennage pendant l’hiver.

**Référence :** [Wikipédia, contributeurs — Shining (film) — version 240708748](https://fr.wikipedia.org/w/index.php?oldid=240708748)

Passage : Introduction : « Le film met en scène Jack Torrance, un écrivain ex-alcoolique et en panne d'inspiration, engagé pendant tout l'hiver comme gardien d'un grand hôtel isolé du Colorado , l'Hôtel Overlook, où il espère surmonter enfin son manque d'inspiration littéraire. »

Consultée le 2026-10-30.

## 04. Qui se cache derrière la caméra ?

**Thème :** Pop culture

Quel réalisateur signe le premier Scream, sorti en 1996 ?

**Réponse : Wes Craven**

- Indice à 2 points : Il a aussi écrit et réalisé Les Griffes de la nuit, sorti en 1984.
- Indice à 1 point : Son prénom est Wes.

Wes Craven réalise Scream ; Kevin Williamson en écrit le scénario.

**Référence :** [Wikipédia, contributeurs — Scream (film, 1996) — version 240769484](https://fr.wikipedia.org/w/index.php?oldid=240769484)

Passage : Introduction : « est un film d'horreur américain réalisé par Wes Craven , écrit par Kevin Williamson , sorti en 1996 . »

Consultée le 2026-10-30.

**Référence :** [Wikipédia, contributeurs — Les Griffes de la nuit — version 240214723](https://fr.wikipedia.org/w/index.php?oldid=240214723)

Passage : Introduction : « Les Griffes de la nuit ( A Nightmare on Elm Street ) est un film d'horreur américain , écrit et réalisé par Wes Craven , et sorti en 1984 . »

Consultée le 2026-10-30.

## 05. Vacances sous tension

**Thème :** Pop culture

Sur quelle île fictive se déroule l’intrigue des Dents de la mer ?

**Réponse : Amity**

- Indice à 2 points : Steven Spielberg réalise ce film sorti en 1975.
- Indice à 1 point : Le nom de l’île commence par « Ami… ».

Le requin menace les baigneurs d’une station balnéaire située sur l’île fictive d’Amity.

**Référence :** [Wikipédia, contributeurs — Les Dents de la mer — version 238363505](https://fr.wikipedia.org/w/index.php?oldid=238363505)

Passage : Introduction : « Les Dents de la mer ( Jaws , litt. « Les Mâchoires ») est un film américain réalisé par Steven Spielberg et sorti en 1975 , » […] « Le film met en scène un grand requin blanc mangeur d'hommes qui attaque les baigneurs d'une station balnéaire de la côte est des États-Unis située sur l'île fictive d'Amity . »

Consultée le 2026-10-30.

## 06. Une ville à l’envers

**Thème :** Pop culture

Dans quelle ville fictive se déroule Stranger Things ?

**Réponse : Hawkins**

- Indice à 2 points : La ville se situe dans l’Indiana.
- Indice à 1 point : L’histoire y commence avec la disparition de Will Byers.

Hawkins est la petite ville fictive de l’Indiana où surviennent les événements surnaturels de la série.

**Référence :** [Wikipédia, contributeurs — Stranger Things — version 239026872](https://fr.wikipedia.org/w/index.php?oldid=239026872)

Passage : Introduction : « La série se déroule de 1983 à 1989 et raconte l’histoire des habitants de la petite ville fictive d’Hawkins, dans l’Indiana, devenu le théâtre d’événements surnaturels après la disparition de Will Byers, un garçon de douze ans, »

Consultée le 2026-10-30.

## 07. Un prénom à exorciser

**Thème :** Pop culture

Comment s’appelle la jeune fille possédée dans L’Exorciste, sorti en 1973 ?

**Réponse : Regan MacNeil**

- Indice à 2 points : Elle est interprétée par Linda Blair.
- Indice à 1 point : Son prénom commence par « Re… ».

Accepter « Regan ». La distribution donne le nom complet Regan Theresa MacNeil.

**Référence :** [Wikipédia, contributeurs — L'Exorciste (film) — version 240583268](https://fr.wikipedia.org/w/index.php?oldid=240583268)

Passage : Introduction et Distribution : « L’Exorciste ( The Exorcist ) est un film d'horreur américain réalisé par William Friedkin et sorti en 1973 . » […] « Il raconte l'histoire d'une petite fille, Regan MacNeil , possédée par un démon, » […] « Linda Blair (VF : Séverine Morisot / Noémie Orphelin ; VQ : Élisabeth Lenormand) : Regan Theresa MacNeil »

Consultée le 2026-10-30.

## 08. Mercredi, avant la série

**Thème :** Pop culture

Quelle actrice interprète Mercredi dans le film La Famille Addams de 1991 ?

**Réponse : Christina Ricci**

- Indice à 2 points : Le prénom de l’actrice est Christina.
- Indice à 1 point : Son nom de famille commence par « Ric… ».

Christina Ricci interprète Mercredi Addams dans ce film réalisé par Barry Sonnenfeld.

**Référence :** [Wikipédia, contributeurs — La Famille Addams (film, 1991) — version 240547298](https://fr.wikipedia.org/w/index.php?oldid=240547298)

Passage : Introduction et Distribution : « La Famille Addams ( The Addams Family ) est un film américain réalisé par Barry Sonnenfeld et sorti en 1991 . » […] « Christina Ricci (VF : Sauvane Delanoe ) : Mercredi Addams, la fille de la famille ( Wednesday en VO ) »

Consultée le 2026-10-30.

## 09. Chambre avec mauvaise surprise

**Thème :** Pop culture

Comment s’appelle le propriétaire du motel dans Psychose ?

**Réponse : Norman Bates**

- Indice à 2 points : Il est interprété par Anthony Perkins.
- Indice à 1 point : Son prénom est Norman.

Norman Bates est le personnage incarné par Anthony Perkins dans le film d’Alfred Hitchcock sorti en 1960.

**Référence :** [Wikipédia, contributeurs — Psychose (film) — version 240698299](https://fr.wikipedia.org/w/index.php?oldid=240698299)

Passage : Introduction : « Psychose ( Psycho ) est un thriller horrifique américain en noir et blanc réalisé par Alfred Hitchcock , sorti en 1960 . » […] « élève Anthony Perkins au rang de célébrité du cinéma. L'acteur y interprète Norman Bates , un jeune homme perturbé, propriétaire d'une vieille demeure surplombant le motel dont il est également propriétaire, »

Consultée le 2026-10-30.

## 10. Un clown dans le caniveau

**Thème :** Pop culture

Dans quel film de 2017 apparaît le clown Grippe-Sou ?

**Réponse : Ça**

- Indice à 2 points : Le film adapte un roman de Stephen King.
- Indice à 1 point : Son titre original est It.

Accepter « Ça », « Ça : Chapitre 1 » ou « It ». Il s’agit de l’adaptation réalisée par Andrés Muschietti.

**Référence :** [Wikipédia, contributeurs — Ça (film, 2017) — version 240632426](https://fr.wikipedia.org/w/index.php?oldid=240632426)

Passage : Introduction et Synopsis : « Ça (intitulé à l'écran Ça : Chapitre 1 ; stylisé ÇA au Québec ; It en version originale) est un film d'horreur américain réalisé par Andrés Muschietti , sorti en 2017 . » […] « Il s'agit d'une adaptation cinématographique du roman Ça de Stephen King , » […] « un clown répondant au nom de Grippe-Sou ( Bill Skarsgård ) »

Consultée le 2026-10-30.

## 11. Ne vous endormez pas

**Thème :** Pop culture

Dans quel film de Wes Craven sorti en 1984 apparaît Freddy Krueger ?

**Réponse : Les Griffes de la nuit**

- Indice à 2 points : Le titre original est A Nightmare on Elm Street.
- Indice à 1 point : Le titre français contient le mot « Griffes ».

Les Griffes de la nuit met en scène Freddy Krueger, qui visite les rêves de Nancy.

**Référence :** [Wikipédia, contributeurs — Les Griffes de la nuit — version 240214723](https://fr.wikipedia.org/w/index.php?oldid=240214723)

Passage : Introduction : « Les Griffes de la nuit ( A Nightmare on Elm Street ) est un film d'horreur américain , écrit et réalisé par Wes Craven , et sorti en 1984 . » […] « Dans sa quête de vérité, elle découvrira que ses rêves sont visités par la réincarnation de Freddy Krueger , »

Consultée le 2026-10-30.

## 12. Attention au faux ami

**Thème :** Pop culture

Qui a réalisé L’Étrange Noël de monsieur Jack, sorti en 1993 ?

**Réponse : Henry Selick**

- Indice à 2 points : Tim Burton a imaginé l’histoire, mais n’a pas réalisé le film.
- Indice à 1 point : Le nom de famille du réalisateur est Selick.

Henry Selick signe la réalisation. Tim Burton a imaginé l’histoire.

**Référence :** [Wikipédia, contributeurs — L'Étrange Noël de monsieur Jack — version 240850274](https://fr.wikipedia.org/w/index.php?oldid=240850274)

Passage : Introduction : « L'Étrange Noël de monsieur Jack ( The Nightmare Before Christmas ) est un film de Noël d'animation américain réalisé par Henry Selick , sorti en 1993 . » […] « Imaginé par Tim Burton , scénarisé par Caroline Thompson » […] « Le film devait être initialement réalisé par Tim Burton, qui a laissé sa place à Henry Selick afin d'achever le tournage de Batman : Le Défi . »

Consultée le 2026-10-30.

## 13. Londres, 1888

**Thème :** Tueurs en série

À quel quartier londonien associe-t-on les crimes attribués à Jack l’Éventreur en 1888 ?

**Réponse : Whitechapel**

- Indice à 2 points : Le quartier se trouve dans l’East End.
- Indice à 1 point : Son nom commence par « White… ».

Whitechapel, dans l’East End de Londres. La question ne suppose aucune identité établie de l’auteur.

**Référence :** [Encyclopædia Britannica — Jack the Ripper | Identity, Facts, Victims, and Suspects](https://www.britannica.com/biography/Jack-the-Ripper)

Passage : Top Questions — Who was Jack the Ripper? : « Between August and November 1888, he murdered at least five women—all prostitutes—in or near the Whitechapel district of London’s East End. » […] « Jack the Ripper was never identified or arrested. »

Consultée le 2026-10-30.

## 14. Des lettres qui défient l’enquête

**Thème :** Tueurs en série

Quel tueur non identifié envoyait des messages chiffrés aux journaux de Californie à la fin des années 1960 ?

**Réponse : Le Zodiac**

- Indice à 2 points : Il adressait notamment des lettres aux journaux de la baie de San Francisco.
- Indice à 1 point : Ses lettres commençaient souvent par « this is the Zodiac speaking ».

Le Zodiac. Britannica le présente comme non identifié ; les hypothèses sur son identité ne sont pas des faits établis.

**Référence :** [Encyclopædia Britannica — Zodiac killer | Name, Never Caught, Letters, Suspects, & Facts](https://www.britannica.com/biography/Zodiac-killer)

Passage : Top Questions et Murders and letters : « The Zodiac killer was an unidentified American serial killer believed to have murdered at least five people in northern California between 1968 and 1969. » […] « typically began with the phrase, “this is the Zodiac speaking.” » […] « Included among the letters were four ciphers or cryptograms, the first of which was sent in three parts to three Bay Area newspapers in July 1969. »

Consultée le 2026-10-30.

## 15. Deux évasions, une même année

**Thème :** Tueurs en série

Quel tueur s’évade à deux reprises alors qu’il est détenu au Colorado en 1977 ?

**Réponse : Ted Bundy**

- Indice à 2 points : Il sera ensuite condamné pour trois meurtres en Floride.
- Indice à 1 point : Son prénom usuel est Ted.

Ted Bundy s’évade du palais de justice d’Aspen à l’été 1977, puis de sa cellule le 31 décembre 1977.

**Référence :** [Encyclopædia Britannica — Ted Bundy | Biography, Last Meal, Crimes, Death, & Facts](https://www.britannica.com/biography/Ted-Bundy)

Passage : Arrest and escape ; Top Questions : « In 1977 Bundy was transferred to a county jail in Aspen , Colorado , while he awaited trial for the murder of a nurse. He escaped that summer, jumping from a second-floor window at the local courthouse. Bundy was arrested several days later in Aspen. He went back to jail, but on December 31, 1977, he staged another escape, this time using a hole in his cell’s ceiling. » […] « In 1979–80 he was convicted of three murders in Florida: »

Consultée le 2026-10-30.

## 16. Une ville du Wisconsin

**Thème :** Tueurs en série

Dans quelle ville du Wisconsin Jeffrey Dahmer a-t-il commis la plupart de ses meurtres ?

**Réponse : Milwaukee**

- Indice à 2 points : Il est également né dans cette ville en 1960.
- Indice à 1 point : La ville figure dans son surnom anglais « The Milwaukee Monster ».

La plupart de ses meurtres ont été commis à Milwaukee. Il ne faut pas en déduire qu’ils y ont tous eu lieu.

**Référence :** [Encyclopædia Britannica — Jeffrey Dahmer | Biography, Crimes, Death, & Facts](https://www.britannica.com/biography/Jeffrey-Dahmer)

Passage : Quick Facts et corps de la notice : « Also called: “The Milwaukee Cannibal” and “The Milwaukee Monster” » […] « born May 21, 1960, Milwaukee , Wisconsin , U.S. » […] « during the next five years he killed—mostly in Milwaukee, Wisconsin—another 15 boys and young men, »

Consultée le 2026-10-30.

## 17. Un personnage de clown

**Thème :** Tueurs en série

Quel tueur américain se produisait notamment sous le nom de « Pogo the Clown » ?

**Réponse : John Wayne Gacy**

- Indice à 2 points : Il est arrêté en décembre 1978.
- Indice à 1 point : Ses deux premiers prénoms sont John Wayne.

John Wayne Gacy apparaissait en clown sous les noms de Pogo ou Patches lors de divers événements.

**Référence :** [Encyclopædia Britannica — John Wayne Gacy | Biography, Murders, Execution, Paintings, & Facts](https://www.britannica.com/biography/John-Wayne-Gacy)

Passage : Top Questions — How was John Wayne Gacy caught? ; Early life and first crimes : « John Wayne Gacy was caught in December 1978 » […] « He later appeared as a clown (“Pogo the Clown” or “Patches the Clown”) at various events. »

Consultée le 2026-10-30.

## 18. Une profession de confiance

**Thème :** Tueurs en série

Quel métier exerçait Harold Shipman ?

**Réponse : Médecin généraliste**

- Indice à 2 points : Il obtient un diplôme de médecine à l’université de Leeds en 1970.
- Indice à 1 point : Son travail consistait à recevoir et soigner des patients.

Accepter « médecin » ou « généraliste ». Britannica précise qu’il exerce comme general practitioner.

**Référence :** [Encyclopædia Britannica — Harold Shipman | Doctor Death, Wife, Cause of Death, & Facts](https://www.britannica.com/biography/Harold-Shipman)

Passage : Life and crimes : « In 1970 Shipman received a medical degree from Leeds University, and a few years later he became a general practitioner in Todmorden in Lancashire. » […] « Harold Shipman was a British doctor »

Consultée le 2026-10-30.

## 19. L’indice était numérique

**Thème :** Tueurs en série

Quel support informatique envoyé à la police aide à identifier Dennis Rader, dit BTK, en 2005 ?

**Réponse : Une disquette**

- Indice à 2 points : Rader avait demandé à la police si ce support pouvait être retracé jusqu’à lui.
- Indice à 1 point : Son nom anglais est « floppy disk ».

Une disquette. Les policiers ont pu la relier à son église, ce qui a aidé à l’identifier.

**Référence :** [Encyclopædia Britannica — Dennis Rader | BTK, Floppy Disk, Murders, & Facts](https://www.britannica.com/biography/Dennis-Rader)

Passage : Top Questions — How was Dennis Rader caught? : « In January 2005 police received a break after recovering a cereal box that included a note in which Rader asked police whether they would be able to trace a floppy disk he wanted to send them. » […] « He then sent them a disk, which the police quickly traced to his church, where he served as president of the congregation. »

Consultée le 2026-10-30.

## 20. Un surnom dans la presse

**Thème :** Tueurs en série

Sous quel surnom anglais Richard Ramirez était-il connu ?

**Réponse : Night Stalker**

- Indice à 2 points : Ses crimes en Californie en 1984–1985 ont provoqué une forte inquiétude.
- Indice à 1 point : Les initiales du surnom sont N. S.

Le surnom est « Night Stalker ». Le nom propre en anglais est la réponse attendue.

**Référence :** [Encyclopædia Britannica — Richard Ramirez | Night Stalker, Death, TV Series, Childhood, & Facts](https://www.britannica.com/biography/Richard-Ramirez)

Passage : Top Questions — Who was Richard Ramirez? : « In 1984–85 he murdered at least 13 people in California. » […] « Dubbed the “Night Stalker,” he triggered widespread panic. »

Consultée le 2026-10-30.

## 21. De l’enquête à la minisérie

**Thème :** Tueurs en série

Quel criminel français a inspiré la minisérie The Serpent de 2021 ?

**Réponse : Charles Sobhraj**

- Indice à 2 points : Ses crimes sont associés à la route des voyageurs en Asie dans les années 1970.
- Indice à 1 point : Son prénom est Charles.

Charles Sobhraj, surnommé « le Serpent ». La minisérie citée est une production BBC–Netflix.

**Référence :** [Encyclopædia Britannica — Charles Sobhraj | The Serpent, The Bikini Killer, Early Life, Crimes, Arrests, Escapes, & Legacy](https://www.britannica.com/biography/Charles-Sobhraj)

Passage : Top Questions et introduction : « Charles Sobhraj, also known as the Serpent or the Bikini Killer, is a French serial killer, smuggler, con artist, and thief known for his crimes along the Asian hippie trail in the 1970s. » […] « his story is recounted in books, documentaries, and dramatizations, including the BBC - Netflix miniseries The Serpent (2021). »

Consultée le 2026-10-30.

## 22. Le Barbe-Bleue de Gambais

**Thème :** Faits divers français

Quel criminel français a été surnommé « le Barbe-Bleue de Gambais » ?

**Réponse : Henri Désiré Landru**

- Indice à 2 points : Il est né à Paris en 1869.
- Indice à 1 point : Ses deux prénoms sont Henri et Désiré.

Accepter « Landru » ou « Henri Désiré Landru ».

**Référence :** [Wikipédia, contributeurs — Henri Désiré Landru — version 240673121](https://fr.wikipedia.org/w/index.php?oldid=240673121)

Passage : Introduction : « Henri Désiré Landru , né le 12 avril 1869 à Paris ( 19 arrondissement ) » […] « Il fut surnommé « le Barbe-Bleue de Gambais ». »

Consultée le 2026-10-30.

## 23. Une adresse dans l’affaire Petiot

**Thème :** Faits divers français

Dans quelle rue parisienne se trouvait l’hôtel particulier au cœur de l’affaire Marcel Petiot ?

**Réponse : Rue Le Sueur**

- Indice à 2 points : L’adresse portait le numéro 21.
- Indice à 1 point : Le nom de la rue commence par « Le S… ».

L’hôtel particulier était situé au 21, rue Le Sueur, à Paris.

**Référence :** [Wikipédia, contributeurs — Marcel Petiot — version 239941829](https://fr.wikipedia.org/w/index.php?oldid=239941829)

Passage : L’affaire Petiot — Le cabinet macabre : « Le 11 août 1941 , il acquiert — ou loue — un hôtel particulier , à Paris, au 21, rue Le Sueur , »

Consultée le 2026-10-30.

## 24. Une page d’histoire judiciaire

**Thème :** Faits divers français

Quel homme est le dernier condamné à avoir été exécuté publiquement en France, en 1939 ?

**Réponse : Eugène Weidmann**

- Indice à 2 points : L’exécution a lieu à Versailles le 17 juin 1939.
- Indice à 1 point : Son prénom est Eugène.

Eugène Weidmann. Il s’agit de la dernière exécution publique, et non de la dernière exécution en France.

**Référence :** [INA — 1939, l’exécution d’Eugène Weidmann — 13 juin 2019, actualisé le 4 août 2020](https://www.ina.fr/ina-eclaire-actu/1939-l-execution-d-eugene-weidmann)

Passage : Chapeau de l’article : « Le 17 juin 1939, le tueur en série Eugène Weidmann était exécuté à Versailles. » […] « il est le dernier condamné à mort exécuté en place publique en France. »

Consultée le 2026-10-30.

## 25. Une reine éclaboussée par un scandale

**Thème :** Faits divers français

Quelle reine de France voit sa réputation atteinte par l’affaire du collier, bien qu’elle n’ait pas participé à l’escroquerie ?

**Réponse : Marie-Antoinette**

- Indice à 2 points : Le scandale éclate en 1785.
- Indice à 1 point : Son prénom composé commence par « Marie ».

Marie-Antoinette. La question porte sur sa réputation : la source précise qu’elle n’était pas coupable dans cette affaire.

**Référence :** [Wikipédia, contributeurs — Affaire du collier de la reine — version 240441409](https://fr.wikipedia.org/w/index.php?oldid=240441409)

Passage : Introduction : « L'achat n'ayant pas été payé et le collier ayant disparu, le scandale éclate le 15 août 1785 . »

Consultée le 2026-10-30.

**Référence :** [Encyclopædia Britannica — Affair of the Diamond Necklace | Summary & Facts](https://www.britannica.com/event/Affair-of-the-Diamond-Necklace)

Passage : Conclusion de la notice : « Though Marie-Antoinette was guiltless, the scandal confirmed the belief of contemporaries in her moral laxness and frivolity. »

Consultée le 2026-10-30.

## 26. L’affaire des sœurs Papin

**Thème :** Faits divers français

Dans quelle ville a lieu le double meurtre commis par les sœurs Papin en 1933 ?

**Réponse : Le Mans**

- Indice à 2 points : Christine et Léa Papin y travaillent comme employées de maison.
- Indice à 1 point : Le nom de la ville commence par « Le M… ».

Le Mans. Le double meurtre a lieu le 2 février 1933.

**Référence :** [Wikipédia, contributeurs — Affaire Papin — version 240296316](https://fr.wikipedia.org/w/index.php?oldid=240296316)

Passage : Introduction : « Christine Papin ( 8 mars 1905 - 18 mai 1937 ) et Léa Papin ( 15 septembre 1911 - 24 juillet 2001 ), plus connues sous le nom des sœurs Papin , sont deux employées de maison ayant commis un double meurtre sur leurs patronnes le 2 février 1933 au Mans . »

Consultée le 2026-10-30.

## 27. Un fait divers sur grand écran

**Thème :** Faits divers français

Qui réalise le film Violette Nozière, sorti au cinéma en 1978 ?

**Réponse : Claude Chabrol**

- Indice à 2 points : Le rôle-titre est interprété par Isabelle Huppert.
- Indice à 1 point : Le prénom du réalisateur est Claude.

Claude Chabrol réalise cette adaptation de l’affaire Nozière, avec Isabelle Huppert dans le rôle-titre.

**Référence :** [Wikipédia, contributeurs — Violette Nozière — version 239496038](https://fr.wikipedia.org/w/index.php?oldid=239496038)

Passage : Cinéma : « réalisé par Claude Chabrol en 1977 . Le rôle-titre est incarné par Isabelle Huppert . » […] « Le film sort au cinéma en France le 24 mai 1978 . »

Consultée le 2026-10-30.

**Référence :** [INA — 1978, Chabrol et Huppert à propos de Violette Nozière — 21 juin 2019](https://www.ina.fr/contenus-editoriaux/articles-editoriaux/1978-chabrol-et-huppert-a-propos-de-violette-noziere/)

Passage : Chapeau de l’article : « Le film Violette Nozière de Claude Chabrol est diffusé ce soir sur Arte. » […] « En 1978, Claude Chabrol et Isabelle Huppert étaient invités pour parler de cette femme »

Consultée le 2026-10-30.

## 28. La rivière d’une affaire non résolue

**Thème :** Faits divers français

Dans quelle rivière Grégory Villemin est-il retrouvé le 16 octobre 1984 ?

**Réponse : La Vologne**

- Indice à 2 points : L’affaire débute dans les Vosges.
- Indice à 1 point : Le nom de la rivière commence par « Vo… ».

La Vologne. La référence présente l’affaire comme non résolue ; la question ne désigne aucun auteur.

**Référence :** [Wikipédia, contributeurs — Affaire Grégory — version 240029826](https://fr.wikipedia.org/w/index.php?oldid=240029826)

Passage : Introduction : « L' affaire Grégory Villemin débute le 16 octobre 1984 dans les Vosges . Grégory, âgé de quatre ans, est enlevé à son domicile de Lépanges-sur-Vologne et retrouvé mort le soir même dans la Vologne , à sept kilomètres de là. Le ou les assassins demeurent inconnus. »

Consultée le 2026-10-30.

## 29. L’homme disparu de l’affaire Seznec

**Thème :** Faits divers français

Quel homme politique disparaît en 1923 lors du voyage à l’origine de l’affaire Seznec ?

**Réponse : Pierre Quéméneur**

- Indice à 2 points : Il est conseiller général du Finistère.
- Indice à 1 point : Son prénom est Pierre.

Pierre Quéméneur. La question porte sur la personne disparue, sans trancher les controverses entourant l’affaire.

**Référence :** [Wikipédia, contributeurs — Affaire Seznec — version 240545549](https://fr.wikipedia.org/w/index.php?oldid=240545549)

Passage : Introduction et L’affaire : « du meurtre de Pierre Quéméneur, conseiller général du Finistère , » […] « L'homme d'affaires et homme politique Pierre Quéméneur disparaît en 1923, pendant un voyage d'affaires qu'il effectuait en automobile avec Guillaume Seznec entre la Bretagne et Paris . »

Consultée le 2026-10-30.

## 30. Poisons à la cour

**Thème :** Faits divers français

Sous le règne de quel roi se déroule l’affaire des Poisons ?

**Réponse : Louis XIV**

- Indice à 2 points : Une juridiction spéciale appelée « chambre ardente » est créée en 1679.
- Indice à 1 point : Madame de Montespan est la maîtresse de ce roi.

Louis XIV. Les accusations rapportées dans cette affaire ne doivent pas être confondues avec des faits prouvés.

**Référence :** [Encyclopædia Britannica — Affair of the Poisons | Poison Plot, Louis XIV, Witchcraft](https://www.britannica.com/event/Affair-of-the-Poisons)

Passage : Corps de la notice : « A special tribunal for the trial of the accused, known as the chambre ardente , was created in April 1679. » […] « Among the many members of French society who were implicated was Madame de Montespan, the mistress of King Louis XIV . »

Consultée le 2026-10-30.
